package entities;


import exceptions.InsufficientStockException;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import model.Packaging;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {
    @Id
    private String isbn;

    private String title;

    private double price;

    private int stock;

    @Column(name = "publish_date")
    private LocalDate publishDate;

    @Column(name = "box")
    @Enumerated(EnumType.STRING)
    private Packaging box;

    @ToString.Exclude
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "producators_products",
            joinColumns = @JoinColumn(name = "isbn_product", referencedColumnName = "isbn"),
            inverseJoinColumns = @JoinColumn(name = "id_authors", referencedColumnName = "id")
    )
    private Set<Producator> porducators = new LinkedHashSet<>();

    public void checkStock(int quantity) throws InsufficientStockException {
        if (this.stock + quantity < 0) {
            throw new InsufficientStockException("Insufficient stock.");
        }
    }
}
