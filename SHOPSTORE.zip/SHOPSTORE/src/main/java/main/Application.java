package main;

import database.DbConnection;
import entities.CustomerAddress;
import entities.Producator;
import entities.Product;
import entities.Customer;
import exceptions.*;
import model.Packaging;
import service.ShopStore;
import service.customers.CustomersService;
import service.customers.HibernateCustomersService;
import service.producators.ProducatorsService;
import service.producators.HibernateProducatorsService;
import service.products.HibernateInventoryService;
import service.products.InventoryService;
import service.shopping_cart.HibernateShoppingCartsService;
import service.shopping_cart.ShoppingCartsService;

import java.nio.channels.ScatteringByteChannel;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Optional;
import java.util.Scanner;

public class Application {

    public static void main(String[] args) {


        ShopStore productStore = new ShopStore(new HibernateInventoryService(), new HibernateShoppingCartsService(),
                new HibernateProducatorsService(), new HibernateCustomersService());

        Scanner scanner = new Scanner(System.in);

        do {
            try {
                System.out.println("***********MAIN MENU***********");
                System.out.println("0. Exit");
                System.out.println("1. Admin");
                System.out.println("2. Client");
                System.out.println("******************************");
                int option = Integer.parseInt(scanner.nextLine());

                switch (option) {
                    case 0:
                        System.exit(0);
                    case 1:
                        boolean backToMainMenu;
                        //admin menu
                        do {
                            displayAdminMenu();
                            backToMainMenu = processAdminOption(scanner, productStore.getInventoryService(), productStore.getAuthorsService(), productStore.getCustomersService() );
                        } while (!backToMainMenu);
                        break;

                    case 2:
                        //client menu
                        System.out.println("What is your customer email?");
                        String email = scanner.nextLine();

                        Optional<Customer> optionalCustomer = productStore.getCustomersService().get(email);

                        if (!optionalCustomer.isPresent()) {
                            System.out.println("Customer does not exist!!");
                        } else {
                            System.out.println("     **** **** Customer found **** ****     ");
                            do {
                                displayClientMenu();
                                backToMainMenu = processClientOption(scanner, optionalCustomer.get(), productStore.getInventoryService(), productStore.getShoppingCartsService());
                            } while (!backToMainMenu);
                        }
                        break;
                    default:
                        System.out.println("Invalid option. Choose 0-2");
                }

            } catch (NumberFormatException e) {
                System.out.println("Invalid value for option. Should be a number");
            }

        } while (true);


    }

    private static boolean processClientOption(Scanner scanner, Customer customer, InventoryService productInventory, ShoppingCartsService shoppingCartsService) {
        String title;
        String isbn;

        System.out.println("Input option: ");
        int option = Integer.parseInt(scanner.nextLine());

        try {
            switch (option) {
                case 0:
                    return true;
                case 1:
                    //add to shopping cart
                    System.out.println("Input isbn: ");
                    isbn = scanner.nextLine();
                    //this throws exception i f does not exist
                    Product product = productInventory.searchByIsbn(isbn);
                    //see if item exists in cart and get its quantity
                    int quantity = shoppingCartsService.getQuantity(customer, product);
                    //check if there is enough stock
                    product.checkStock(quantity != 0 ? -(quantity + 1) : -1);

                    //add to cart
                    shoppingCartsService.addToCart(customer, product);

//                    System.out.println("Item successfully added!");

                    break;
                case 2:
                    // remove item
                    System.out.println("Which item?");
                    System.out.println("Input isbn for product you wish to delete from cart.");
                     isbn = scanner.nextLine();
                    // find the product
                     product = productInventory.searchByIsbn(isbn);
                    quantity = shoppingCartsService.getQuantity(customer, product);
                    if (product == null) {
                        System.out.println("Product not found.");
                        break;
                    }
                    if(quantity ==0)
                        System.out.println("No item to delete");
                    try {
                        // remove product from cart
                        shoppingCartsService.removeFromCart(customer, product);
                    } catch (InexistentItemException e) {
                        System.out.println(e.getMessage());
                    }

                    break;

                case 3:
                    //update quantity
                    System.out.println("Input isbn: ");
                    isbn = scanner.nextLine();
                    //this throws exception if does not exist
                    product = productInventory.searchByIsbn(isbn);
                    System.out.println("Input new quantity: ");
                    int newQuantity = Integer.parseInt(scanner.nextLine());

                    try {
                        shoppingCartsService.updateQuantity(customer, product, newQuantity);
                        System.out.println("Quantity successfully updated!");

                    } catch (InexistentItemException | InvalidQuantityException e) {
                        throw new RuntimeException(e);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    break;

                case 4:
                    //Display shopping cart items
                    System.out.println("Displaying items currently in the shopping cart");
                    shoppingCartsService.displayAll(customer);

                    break;
                case 5:
                    // display all
                    productInventory.displayAll();
                    break;

                default:
                    throw new IllegalStateException("Unexpected value: " + option);
            }

        } catch (InexistentProdusException e) {
            System.out.println("Warning: " + e.getMessage());
            System.out.println("Choose from: ");

        } catch (InsufficientStockException e) {
            System.out.println("Warning: " + e.getMessage());
        }

        return false;
    }


    private static boolean processAdminOption(Scanner scanner, InventoryService productInventory, ProducatorsService authorsService, CustomersService customerService) {
        String title;
        int stock;
        double price;
        try {
            System.out.println("Input option: ");
            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 0:
                    return true;
                case 1:
                    //add product
                    System.out.println("Input isbn:");
                    String isbn = scanner.nextLine();

                    System.out.println("Input title: ");
                    title = scanner.nextLine();

                    System.out.println("Input stock:");
                    stock = Integer.parseInt(scanner.nextLine());

                    System.out.println("Input price: ");
                    price = Double.parseDouble(scanner.nextLine());

                    System.out.println("Input publishing date (dd-MM-yyyy)");
                    String dateStr = scanner.nextLine();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    LocalDate localDate = LocalDate.parse(dateStr, formatter);

                    System.out.println("Input cover type (PLASTIC, POLYSTYRENE, ABS): ");
                    Packaging box = Packaging.safeValueOf(scanner.nextLine());

                    if (box == null) {
                        System.out.println("Invalid value for cover type. ");
                    } else {
                        try {
                            Connection conn = DbConnection.INSTANCE.getConnection();

                            // Create a prepared statement
                            String sql = "INSERT INTO products (isbn, title, stock, price, publish_date, box) VALUES (?, ?, ?, ?, ?, ?)";
                            PreparedStatement pstmt = conn.prepareStatement(sql);

                            // Bind the values to the prepared statement
                            pstmt.setString(1, isbn);
                            pstmt.setString(2, title);
                            pstmt.setInt(3, stock);
                            pstmt.setDouble(4, price);
                            pstmt.setDate(5, java.sql.Date.valueOf(localDate));
                            pstmt.setString(6, box.toString());

                            // Execute the prepared statement
                            pstmt.executeUpdate();

                            System.out.println("Product added successfully.");

                        } catch (SQLException e) {
                            System.out.println("Error adding product: " + e.getMessage());
                        }
                    }
                    break;

                case 2:
                    //remove product
                    System.out.println("Input title: ");
                    title = scanner.nextLine();
                    productInventory.delete(title);
                    break;
                case 3:
                    // search by title
                    System.out.println("Input title: ");
                    title = scanner.nextLine();
                    productInventory.searchByTitle(title);
                    break;

                case 4:
                    // search by isbn
                    productInventory.searchByIsbnn();
                    break;
                case 5:
                    //update quantity
                    productInventory.updateQuantity();
                    break;
                case 6:
                    //update price
                    productInventory.updatePrice();
                    break;
                case 7:
                    // display all
                    productInventory.displayAll();
                    break;
                case 8:
                    //add customeraddress
                    System.out.println("Input id adress:");
                    int ida = Integer.parseInt(scanner.nextLine());

                    System.out.println("Input country: ");
                    String country = scanner.nextLine();

                    System.out.println("Input city:");
                    String city = scanner.nextLine();

                    System.out.println("Input street:");
                    String street = scanner.nextLine();

                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        String sql = "INSERT INTO customer_address (id, country, city, street) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        // Bind the values to the prepared statement
                        pstmt.setInt(1, ida);
                        pstmt.setString(2, country);
                        pstmt.setString(3, city);
                        pstmt.setString(4, street);
                        // Execute the prepared statement
                        pstmt.executeUpdate();

                        System.out.println("CostumerAddress added successfully.");

                    } catch (SQLException e) {
                        System.out.println("Error adding costumer/address: " + e.getMessage());
                    }
                    break;

                case 9:
                    //remove costumeradress
                    System.out.println("Input id: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "DELETE FROM customer_address WHERE id = ?";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Bind the value to the prepared statement
                        pstmt.setInt(1, id);

                        // Execute the prepared statement
                        int rowsDeleted = pstmt.executeUpdate();

                        if (rowsDeleted > 0) {
                            System.out.println("CustomerAddress deleted successfully.");
                        } else {
                            System.out.println("Customer not found.");
                        }

                    } catch (SQLException e) {
                        System.out.println("Error removing product: " + e.getMessage());
                    }
                    break;

                case 10:
                    // display costumer address
                    System.out.println("Displaying all available customer address");
                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "SELECT * FROM customer_address";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Execute the prepared statement and get the result set
                        ResultSet rs = pstmt.executeQuery();

                        while (rs.next()) {
                            int foundId = rs.getInt("id");
                            String foundCountry = rs.getString("country");
                            String foundCity = rs.getString("city");
                            String foundStreet = rs.getString("street");

                            CustomerAddress foundCustomerAddress = CustomerAddress.builder()
                                    .id(foundId)
                                    .country(foundCountry)
                                    .city(foundCity)
                                    .street(foundStreet)
                                    .build();

                            System.out.println(foundCustomerAddress);
                        }

                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    System.out.println("******* **** That is all! **** ******");

                    break;

                case 11:
                    //add customer
                    System.out.println(" First add customer addres");
                    //add customeraddress
                    System.out.println("Input id adress:");
                     ida = Integer.parseInt(scanner.nextLine());

                    System.out.println("Input country: ");
                     country = scanner.nextLine();

                    System.out.println("Input city:");
                    city = scanner.nextLine();

                    System.out.println("Input street:");
                     street = scanner.nextLine();

                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        String sql = "INSERT INTO customer_address (id, country, city, street) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmt = conn.prepareStatement(sql);
                        // Bind the values to the prepared statement
                        pstmt.setInt(1, ida);
                        pstmt.setString(2, country);
                        pstmt.setString(3, city);
                        pstmt.setString(4, street);
                        // Execute the prepared statement
                        pstmt.executeUpdate();

                        System.out.println("CostumerAddress added successfully.");

                    } catch (SQLException e) {
                        System.out.println("Error adding costumer/address: " + e.getMessage());
                    }

                    System.out.println("Input id customers:");
                    int idc = Integer.parseInt(scanner.nextLine());

                    System.out.println("Input name: ");
                    String name = scanner.nextLine();

                    System.out.println("Input email:");
                    String email = scanner.nextLine();

                    System.out.println("Input id adress:");
                    ida = Integer.parseInt(scanner.nextLine());

                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "INSERT INTO customers (id, name, email, id_address) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Bind the values to the prepared statement
                        pstmt.setInt(1, idc);
                        pstmt.setString(2, name);
                        pstmt.setString(3, email);
                        pstmt.setInt(4, ida);
                        // Execute the prepared statement
                        pstmt.executeUpdate();

                        System.out.println("Costumer added successfully.");
                    } catch (SQLException e) {
                        System.out.println("Error adding costumer: " + e.getMessage());
                    }
                    break;
                case 12:
                    //remove costumer
                    System.out.println("Input ida: ");
                    ida = Integer.parseInt(scanner.nextLine());
                    customerService.delete(ida);
                    break;
                case 13:
                    // display costumer
                    System.out.println("Displaying all available customer");
                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "SELECT * FROM customers";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Execute the prepared statement and get the result set
                        ResultSet rs = pstmt.executeQuery();

                        while (rs.next()) {
                            int foundId = rs.getInt("id");
                            String foundName = rs.getString("name");
                            String foundEmail = rs.getString("email");

                            Customer foundCustomer = Customer.builder()
                                    .id(foundId)
                                    .name(foundName)
                                    .email(foundEmail)
                                    .build();

                            System.out.println(foundCustomer);
                        }

                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    System.out.println("******* **** That is all! **** ******");

                    break;

                case 14:
                    //add producators
                    System.out.println("Input id:");
                    id = Integer.parseInt(scanner.nextLine());

                    System.out.println("Input name: ");
                    name = scanner.nextLine();

                    System.out.println("Input email:");
                    email = scanner.nextLine();

                    System.out.println("Input publishing date (dd-MM-yyyy)");
                    String dateProducator = scanner.nextLine();
                    DateTimeFormatter formatterProduator = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    LocalDate localDateProducator = LocalDate.parse(dateProducator, formatterProduator);

                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "INSERT INTO producators (id, name, email, birth_date) VALUES (?, ?, ?, ?)";
                        PreparedStatement pstmtP = conn.prepareStatement(sql);

                        // Bind the values to the prepared statement
                        pstmtP.setInt(1, id);
                        pstmtP.setString(2, name);
                        pstmtP.setString(3, email);
                        pstmtP.setDate(4, java.sql.Date.valueOf(localDateProducator));

                        // Execute the prepared statement
                        pstmtP.executeUpdate();

                        System.out.println("Producators added successfully.");

                    } catch (SQLException e) {
                        System.out.println("Error adding product: " + e.getMessage());
                    }
                    break;

                case 15:
                    //remove producators
                    System.out.println("Input id:");
                    id = Integer.parseInt(scanner.nextLine());
                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "DELETE FROM producators WHERE id = ?";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Bind the value to the prepared statement
                        pstmt.setInt(1, id);

                        // Execute the prepared statement
                        int rowsDeleted = pstmt.executeUpdate();

                        if (rowsDeleted > 0) {
                            System.out.println("Producators deleted successfully.");
                        } else {
                            System.out.println("Producators not found.");
                        }

                    } catch (SQLException e) {
                        System.out.println("Error removing producators: " + e.getMessage());
                    }
                    break;

                case 16:
                    System.out.println("Displaying all available producators");
                    try {
                        Connection conn = DbConnection.INSTANCE.getConnection();

                        // Create a prepared statement
                        String sql = "SELECT * FROM producators";
                        PreparedStatement pstmt = conn.prepareStatement(sql);

                        // Execute the prepared statement and get the result set
                        ResultSet rs = pstmt.executeQuery();

                        while (rs.next()) {
                            int foundId = rs.getInt("id");
                            String foundName = rs.getString("name");
                            String foundEmail = rs.getString("email");
                            LocalDate foundPublishDate = rs.getDate("birth_date").toLocalDate();

                            Producator foundProducators = Producator.builder()
                                    .id(foundId)
                                    .name(foundName)
                                    .email(foundEmail)
                                    .birthDate(foundPublishDate)
                                    .build();
                            System.out.println(foundProducators);
                        }

                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    break;


            default:
                    System.out.println("Invalid option");

            }

        } catch (DateTimeParseException | InexistentProdusException e) {
            System.out.println("Invalid date.");
        }
        return false;
    }

    private static void displayAdminMenu() {

        System.out.println("********ADMIN MENU***********");
        System.out.println("0. Back to main menu");
        System.out.println("1. Add product");
        System.out.println("2. Remove product");
        System.out.println("3. Search by title");
        System.out.println("4. Search by isbn");
        System.out.println("5. Update quantity");
        System.out.println("6. Update price");
        System.out.println("7. Display all product");
        System.out.println("8. Add customer address");
        System.out.println("9. Remove customer address");
        System.out.println("10. Display customer address");
        System.out.println("11. Add customer");
        System.out.println("12. Remove customer");
        System.out.println("13. Display customer");
        System.out.println("14. Add producator");
        System.out.println("15. Remove producator");
        System.out.println("16. Display producator");
        System.out.println("*****************************");
    }


    private static void displayClientMenu() {
        System.out.println("********CLIENT MENU***********");
        System.out.println("0. Back to main menu");
        System.out.println("1. Add to cart");
        System.out.println("2. Remove from cart");
        System.out.println("3. Update quantity");
        System.out.println("4. Display shopping cart items");
        System.out.println("5. Display all products");
        System.out.println("*****************************");
    }
}
