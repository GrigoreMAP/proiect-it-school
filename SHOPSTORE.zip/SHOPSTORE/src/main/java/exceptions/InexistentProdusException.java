package exceptions;

public class InexistentProdusException extends Exception {

    public InexistentProdusException(String message) {
        super(message);
    }
}
