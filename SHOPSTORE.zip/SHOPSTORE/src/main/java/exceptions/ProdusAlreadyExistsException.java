package exceptions;

public class ProdusAlreadyExistsException extends Exception{

    public ProdusAlreadyExistsException(String message) {
        super(message);
    }
}
