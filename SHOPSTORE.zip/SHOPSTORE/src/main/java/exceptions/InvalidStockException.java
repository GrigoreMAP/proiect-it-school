package exceptions;

public class InvalidStockException extends Exception{
    public InvalidStockException(String message) {
        super(message);
    }
}
