package model;

public enum Packaging {

    PLASTIC, POLYSTYRENE, ABS;

    public static Packaging safeValueOf(String value) {
        try {
            return Packaging.valueOf(value);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
