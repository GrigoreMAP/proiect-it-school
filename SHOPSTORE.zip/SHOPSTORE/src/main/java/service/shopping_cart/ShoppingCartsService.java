package service.shopping_cart;

import entities.Product;
import entities.Customer;
import exceptions.InexistentItemException;
import exceptions.InsufficientStockException;
import exceptions.InvalidQuantityException;

import java.sql.SQLException;


public interface ShoppingCartsService {

    void addToCart(Customer customer, Product product);

    void removeFromCart(Customer customer, Product product) throws InexistentItemException;

    void updateQuantity(Customer customer, Product product, int quantity) throws InvalidQuantityException, InexistentItemException, SQLException, InsufficientStockException;

    int getQuantity(Customer customer, Product product);

    //display all items in shopping cart - OPEN
    void displayAll(Customer customer);
}
