package service.shopping_cart;

import database.DbConnection;
import entities.Product;
import entities.Customer;
import entities.ShoppingCart;
import entities.ShoppingCartItem;
import entities.ShoppingCartItemPK;
import exceptions.InexistentItemException;
import exceptions.InsufficientStockException;
import exceptions.InvalidQuantityException;
import jakarta.persistence.Query;
import model.Packaging;
import model.ShoppingCartStatus;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

public class HibernateShoppingCartsService implements ShoppingCartsService {

    private SessionFactory sessionFactory;

    public HibernateShoppingCartsService() {
        this.sessionFactory = DbConnection.INSTANCE.getSessionFactory();
    }

    @Override
    public void addToCart(Customer customer, Product product) {

        Session session = this.sessionFactory.openSession();

        Transaction transaction = session.beginTransaction();

        ShoppingCart openShoppingCart = null;
        for (ShoppingCart shoppingCart : customer.getShoppingCarts()) {
            if (shoppingCart.getStatus().equals(ShoppingCartStatus.OPEN)) {
                openShoppingCart = shoppingCart;
                break;
            }
        }

        ShoppingCart customerShoppingCart = null;
        if (openShoppingCart == null) {
            //we don't have an open shopping cart

            customerShoppingCart = new ShoppingCart();

            customerShoppingCart.setId(System.currentTimeMillis());
            customerShoppingCart.setStatus(ShoppingCartStatus.OPEN);
            customerShoppingCart.setLastEdited(LocalDateTime.now());
            customerShoppingCart.setCustomer(customer);

            //customer is in NEW state
            customer.getShoppingCarts().add(customerShoppingCart);

            session.merge(customerShoppingCart);


        } else {
            //customer already has an open shopping cart
            //insert or update just the item
            customerShoppingCart = openShoppingCart;
        }

        //here we have a shopping cart for sure

        boolean itemExists = false;
        for (ShoppingCartItem item : customerShoppingCart.getItems()) {
            if (item.getProduct().getIsbn().equals(product.getIsbn())) {
                itemExists = true;
                System.out.println("Item allready exist you just cand update quantity is this case  ");
                return;

            }
        }

        if (!itemExists) {
            //we need to add it
            ShoppingCartItem newShoppingCartItem = new ShoppingCartItem();
            newShoppingCartItem.setQuantity(1);
            newShoppingCartItem.setProduct(product);
            newShoppingCartItem.setShoppingCart(customerShoppingCart);
            newShoppingCartItem.setId(new ShoppingCartItemPK(product.getIsbn(), customerShoppingCart.getId()));

            int oldStock = product.getStock();
            int requestedQuantity = newShoppingCartItem.getQuantity();
            if (oldStock >= requestedQuantity) {
                int newStock = oldStock - requestedQuantity;
                product.setStock(newStock);
                session.merge(product);
            } else {
                // Handle insufficient stock error
                throw new RuntimeException("Insufficient stock for product: " + product.getTitle());
            }

            session.merge(newShoppingCartItem);
            customerShoppingCart.getItems().add(newShoppingCartItem);
        }

        transaction.commit();
        System.out.println("Item successfully added!");
    }


    @Override
    public void removeFromCart(Customer customer, Product product) throws InexistentItemException {

        Session session = this.sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Retrieve the open shopping cart for the customer
        ShoppingCart openShoppingCart = null;
        for (ShoppingCart shoppingCart : customer.getShoppingCarts()) {
            if (shoppingCart.getStatus().equals(ShoppingCartStatus.OPEN)) {
                openShoppingCart = shoppingCart;
                break;
            }
        }

        if (openShoppingCart != null) {
            // Remove the item from the shopping cart
            ShoppingCartItem itemToRemove = null;
            for (ShoppingCartItem item : openShoppingCart.getItems()) {
                if (item.getProduct().getIsbn().equals(product.getIsbn())) {
                    itemToRemove = item;
                    break;
                }
            }

            if (itemToRemove != null) {
                openShoppingCart.getItems().remove(itemToRemove);
                session.delete(itemToRemove);

                // Add the removed item quantity back to the product stock
                int removedQuantity = itemToRemove.getQuantity();
                int currentStock = product.getStock();
                int newStock = currentStock + removedQuantity;
                product.setStock(newStock);
                session.merge(product);
                System.out.println("Item deleted from shop store");
            }
        }
        transaction.commit();

    }

    @Override
    public void updateQuantity(Customer customer, Product product, int quantity) throws InvalidQuantityException, InexistentItemException, SQLException, InsufficientStockException {

            if (quantity < 0) {
                throw new InsufficientStockException("Quantity cannot be negative.");
            }
        int availableStock = product.getStock(); // Get the available stock of the product
        if ( quantity > availableStock) {
            throw new InsufficientStockException("Insufficient stock for the requested quantity.");
        }


            Session session = this.sessionFactory.openSession();
            Transaction transaction = session.beginTransaction();

            // Retrieve the open shopping cart for the customer
            ShoppingCart openShoppingCart = null;
            for (ShoppingCart shoppingCart : customer.getShoppingCarts()) {
                if (shoppingCart.getStatus().equals(ShoppingCartStatus.OPEN)) {
                    openShoppingCart = shoppingCart;
                    break;
                }
            }

            ShoppingCart customerShoppingCart = null;
            if (openShoppingCart == null) {
                // Create a new shopping cart if none exists
                customerShoppingCart = new ShoppingCart();
                customerShoppingCart.setId(System.currentTimeMillis());
                customerShoppingCart.setStatus(ShoppingCartStatus.OPEN);
                customerShoppingCart.setLastEdited(LocalDateTime.now());
                customerShoppingCart.setCustomer(customer);

                // Add the shopping cart to the customer
                customer.getShoppingCarts().add(customerShoppingCart);
                session.merge(customerShoppingCart);
            } else {
                // Use the existing open shopping cart
                customerShoppingCart = openShoppingCart;
            }

            // Check if the item already exists in the shopping cart
            boolean itemExists = false;
            for (ShoppingCartItem item : customerShoppingCart.getItems()) {
                if (item.getProduct().getIsbn().equals(product.getIsbn())) {
                    itemExists = true;

                    if (quantity == 0) {
                        // Remove the item from the shopping cart if quantity is zero
                        customerShoppingCart.getItems().remove(item);
                        session.delete(item);
                    } else {
                        int initialQuantity = item.getQuantity();
                        System.out.println( initialQuantity);
                        availableStock = product.getStock(); // Get the available stock of the product
                        int stockDifference = initialQuantity - quantity;
                        if (stockDifference > availableStock) {
                            throw new InvalidQuantityException("Quantity cannot be bigger than the available stock.");
                        }

                        item.setQuantity(quantity);
                        item.getProduct().setStock(availableStock + stockDifference); // Update the available stock

                        session.merge(item);
                        session.merge(item.getProduct()); // Update the product's stock in the database
                    }

                    break;
                }
            }

            if (!itemExists && quantity > 0) {
                // Add the item to the shopping cart if it doesn't exist and quantity is greater than zero
                ShoppingCartItem newShoppingCartItem = new ShoppingCartItem();
                newShoppingCartItem.setQuantity(quantity);
                newShoppingCartItem.setProduct(product);
                newShoppingCartItem.setShoppingCart(customerShoppingCart);
                newShoppingCartItem.setId(new ShoppingCartItemPK(product.getIsbn(), customerShoppingCart.getId()));

                availableStock = product.getStock(); // Get the available stock of the product
                if (newShoppingCartItem.getQuantity() > availableStock) {
                    throw new InvalidQuantityException("Quantity cannot be bigger than the available stock.");
                }

                newShoppingCartItem.getProduct().setStock(availableStock - quantity); // Update the available stock

                session.merge(newShoppingCartItem);
                session.merge(newShoppingCartItem.getProduct()); // Update the product's stock in the database

                customerShoppingCart.getItems().add(newShoppingCartItem);
            }

            transaction.commit();
        }


//        if (quantity < 0) {
//            throw new InvalidQuantityException("Quantity cannot be negative.");
//        }
//        int availableStock = product.getStock(); // Get the available stock of the product
//        if ( quantity > availableStock) {
//            throw new InsufficientStockException("Insufficient stock for the requested quantity.");
//        }
//
//        Session session = this.sessionFactory.openSession();
//        Transaction transaction = session.beginTransaction();
//
//        // Retrieve the open shopping cart for the customer
//        ShoppingCart openShoppingCart = null;
//        for (ShoppingCart shoppingCart : customer.getShoppingCarts()) {
//            if (shoppingCart.getStatus().equals(ShoppingCartStatus.OPEN)) {
//                openShoppingCart = shoppingCart;
//                break;
//            }
//        }
//
//        ShoppingCart customerShoppingCart = null;
//        if (openShoppingCart == null) {
//            // Create a new shopping cart if none exists
//            customerShoppingCart = new ShoppingCart();
//            customerShoppingCart.setId(System.currentTimeMillis());
//            customerShoppingCart.setStatus(ShoppingCartStatus.OPEN);
//            customerShoppingCart.setLastEdited(LocalDateTime.now());
//            customerShoppingCart.setCustomer(customer);
//
//            // Add the shopping cart to the customer
//            customer.getShoppingCarts().add(customerShoppingCart);
//            session.merge(customerShoppingCart);
//        } else {
//            // Use the existing open shopping cart
//            customerShoppingCart = openShoppingCart;
//        }
//
//        // Check if the item already exists in the shopping cart
//        boolean itemExists = false;
//        for (ShoppingCartItem item : customerShoppingCart.getItems()) {
//            if (item.getProduct().getIsbn().equals(product.getIsbn())) {
//                itemExists = true;
//
//                if (quantity == 0) {
//                    // Remove the item from the shopping cart if quantity is zero
//                    customerShoppingCart.getItems().remove(item);
//                    session.delete(item);
//                } else {
//                    int initialQuantity = item.getQuantity();
//                    availableStock = product.getStock(); // Get the available stock of the product
//                    int stockDifference = initialQuantity - quantity;
//                    if (stockDifference > availableStock) {
//                        throw new InsufficientStockException("Insufficient stock for the requested quantity.");
//                    }
//
//                    item.setQuantity(quantity);
//                    int newStock = availableStock + stockDifference;
//                    product.setStock(newStock); // Update the available stock
//
//                    session.merge(item);
//                    session.merge(product); // Update the product's stock in the database
//                }
//                break;
//            }
//        }
//
//        if (!itemExists && quantity > 0) {
//            // Add the item to the shopping cart if it doesn't exist and quantity is greater than zero
//            ShoppingCartItem newShoppingCartItem = new ShoppingCartItem();
//            newShoppingCartItem.setQuantity(quantity);
//            newShoppingCartItem.setProduct(product);
//            newShoppingCartItem.setShoppingCart(customerShoppingCart);
//            newShoppingCartItem.setId(new ShoppingCartItemPK(product.getIsbn(), customerShoppingCart.getId()));
//
//            availableStock = product.getStock(); // Get the available stock of the product
//            if ( quantity > availableStock) {
//                throw new InsufficientStockException("Insufficient stock for the requested quantity.");
//            }
//
//            int newStock = availableStock - quantity;
//            product.setStock(newStock); // Update the available stock
//
//            session.merge(newShoppingCartItem);
//            session.merge(product); // Update the product's stock in the database
//
//            customerShoppingCart.getItems().add(newShoppingCartItem);
//        }
//
//        transaction.commit();
//    }
    @Override
    public int getQuantity(Customer customer, Product product) {
        Session session = this.sessionFactory.openSession();

        Query query = session.createNamedQuery("getQuantity", Integer.class);
        query.setParameter("isbn", product.getIsbn());
        query.setParameter("id", customer.getId());

        List<Integer> result = query.getResultList();
        if (result.isEmpty()) {
            return 0;
        } else {
            return result.get(0);
        }
    }

    @Override
    public void displayAll(Customer customer) {
        Session session = this.sessionFactory.openSession();
        String queryString = "SELECT sci.product.isbn, sci.product.title, sci.quantity FROM ShoppingCartItem sci "
                + "JOIN sci.shoppingCart sc "
                + "WHERE sc.customer = :customer AND sc.status = :status";
        List<Object[]> resultList = session.createQuery(queryString)
                .setParameter("customer", customer)
                .setParameter("status", ShoppingCartStatus.OPEN)
                .getResultList();
        if (resultList.isEmpty()) {
            System.out.println("No items found in the shopping cart.");
        } else {
            for (Object[] result : resultList) {
                String isbn = (String) result[0];
                String name = (String) result [1];
                int quantity = (int) result[2];

                System.out.println("ISBN: " + isbn + ", Quantity: " + quantity + ", TITLE: " + name);
            }
        }
    }
}

