package service.customers;

import database.DbConnection;
import entities.Customer;
import exceptions.InexistentProdusException;
import jakarta.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class HibernateCustomersService implements CustomersService {

    private SessionFactory sessionFactory;
 int ida;
    public HibernateCustomersService() {
        this.sessionFactory = DbConnection.INSTANCE.getSessionFactory();
    }


    @Override
    public Optional<Customer> get(String email) {
        Session session = this.sessionFactory.openSession();

        Query query = session.createNamedQuery("findByEmail", Customer.class);
        query.setParameter("email", email);

        List<Customer> customers = query.getResultList();
        // PERSISTENT

//        session.close();

        //DETACHED

        if (customers.isEmpty()) {
            return Optional.empty();
        } else {
            return Optional.of(customers.get(0));
        }
    }

    @Override
    public Customer delete(int ida) throws InexistentProdusException {
        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            // Create a prepared statement
            String sql = "DELETE FROM customers WHERE id_address = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Bind the value to the prepared statement
            pstmt.setInt(1, ida);

            // Execute the prepared statement
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error removing product: " + e.getMessage());
        }
        return null;
    }

    @Override
    public void add(Customer customer) {

    }

    @Override
    public void update(Customer customer) {

    }
}
