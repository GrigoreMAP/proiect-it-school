package service.customers;

import entities.Customer;
import entities.Product;
import exceptions.InexistentProdusException;

import java.util.Optional;

public interface CustomersService {

    Optional<Customer> get(String email);
    Customer delete(int ida) throws InexistentProdusException;

    void add(Customer customer);

    void update(Customer customer);
}
