package service.producators;

import entities.Producator;

import java.util.Optional;

public interface ProducatorsService {

    void add(Producator author);

    void delete(Producator author);

    void update(Producator author);

    Optional<Producator> get(int id);

    Optional<Producator> getByName(String name);

    Optional<Producator> getByEmail(String email);
}
