package service;

import lombok.AllArgsConstructor;
import lombok.Getter;
import service.producators.ProducatorsService;
import service.products.InventoryService;
import service.customers.CustomersService;
import service.shopping_cart.ShoppingCartsService;

@Getter
@AllArgsConstructor
public class ShopStore {

    private InventoryService inventoryService;
    private ShoppingCartsService shoppingCartsService;
    private ProducatorsService authorsService;
    private CustomersService customersService;





}
