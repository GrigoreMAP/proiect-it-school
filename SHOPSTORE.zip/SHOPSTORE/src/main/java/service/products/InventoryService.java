package service.products;

import entities.Product;
import exceptions.InexistentProdusException;

public interface InventoryService {

    Product delete(String title) throws InexistentProdusException;

    void updatePrice();
    void updateQuantity();

    void searchByIsbnn();

    Product searchByIsbn(String isbn) throws InexistentProdusException;
    Product searchByTitle(String title) throws InexistentProdusException;

    void displayAll();

}


