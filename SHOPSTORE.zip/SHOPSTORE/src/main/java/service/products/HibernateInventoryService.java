package service.products;

import database.DbConnection;
import entities.Product;
import exceptions.InexistentProdusException;
import model.Packaging;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

public class HibernateInventoryService implements InventoryService {

    private SessionFactory sessionFactory;
    String title;
    int stock;
    String isbn;


    Scanner scanner = new Scanner(System.in);
    public HibernateInventoryService() {
        this.sessionFactory = DbConnection.INSTANCE.getSessionFactory();
    }


    @Override
    public Product delete(String title) throws InexistentProdusException {  //remove product

        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            // Create a prepared statement
            String sql = "DELETE FROM products WHERE title = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Bind the value to the prepared statement
            pstmt.setString(1, title);

            // Execute the prepared statement
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error removing product: " + e.getMessage());
        } return null;
     }
    @Override
    public void updatePrice() {
        //update price
        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            System.out.println("Input title: ");
             String title = scanner.nextLine();

            System.out.println("Input new price: ");
           double price = Double.parseDouble(scanner.nextLine());

            // Search for the product by title
            String searchSql = "SELECT * FROM products WHERE title = ?";
            PreparedStatement searchPstmt = conn.prepareStatement(searchSql);
            searchPstmt.setString(1, title);
            ResultSet rs = searchPstmt.executeQuery();

            if (rs.next()) {
               String isbn = rs.getString("isbn");

                // Update the price of the product with the given ISBN
                String updateSql = "UPDATE products SET price = ? WHERE isbn = ?";
                PreparedStatement updatePstmt = conn.prepareStatement(updateSql);
                updatePstmt.setDouble(1, price);
                updatePstmt.setString(2, isbn);
                int rowsUpdated = updatePstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("Price updated successfully.");
                } else {
                    System.out.println("Failed to update price.");
                }

            } else {
                System.out.println("No product found with the given title.");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void updateQuantity() {
        //update stock

        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            // Prompt user for input
            System.out.println("Input title: ");
            title = scanner.nextLine();

            System.out.println("Input new stock: ");
            stock = Integer.parseInt(scanner.nextLine());

            // Find book by title
            String sqlFind = "SELECT * FROM products WHERE title = ?";
            PreparedStatement pstmtFind = conn.prepareStatement(sqlFind);
            pstmtFind.setString(1, title);
            ResultSet rsFind = pstmtFind.executeQuery();

            if (rsFind.next()) {
                String isbn = rsFind.getString("isbn");

                // Update stock
                String sqlUpdate = "UPDATE products SET stock = ? WHERE isbn = ?";
                PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate);
                pstmtUpdate.setInt(1, stock);
                pstmtUpdate.setString(2, isbn);
                int rowCount = pstmtUpdate.executeUpdate();

                if (rowCount > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Error updating stock.");
                }
            } else {
                System.out.println("Product not found.");
            }

            // Close the result set, prepared statement, and database connection

        } catch (SQLException e) {
            System.out.println("Error updating stock: " + e.getMessage());
            System.out.println(e);
        }

    }

    @Override
    public void searchByIsbnn() {
        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            System.out.println("Input isbn: ");
            isbn = scanner.nextLine();;

            // Create a prepared statement
            String sql = "SELECT * FROM products WHERE isbn = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Bind the isbn value to the prepared statement
            pstmt.setString(1, isbn);

            // Execute the prepared statement and get the result set
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String foundTitle = rs.getString("title");
                int foundStock = rs.getInt("stock");
                double foundPrice = rs.getDouble("price");
                LocalDate foundPublishDate = rs.getDate("publish_date").toLocalDate();
                Packaging foundPackaging = Packaging.valueOf(rs.getString("box"));

                Product foundProduct = Product.builder()
                        .isbn(isbn)
                        .title(foundTitle)
                        .stock(foundStock)
                        .price(foundPrice)
                        .publishDate(foundPublishDate)
                        .box(foundPackaging)
                        .build();

                System.out.println("Found: " + foundProduct);
            } else {
                System.out.println("Product not found.");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public Product searchByIsbn(String isbn) throws InexistentProdusException {
            Session session = this.sessionFactory.openSession();

            Product product = session.get(Product.class, isbn);
            //PERSISTENT

            session.close();

            //product will DETACHED
            if (product == null) {
                throw new InexistentProdusException("Product does not exist");
            } else {
                return product;
            }

        }

    @Override
    public Product searchByTitle(String title) throws InexistentProdusException {
        //search by title

        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            // Create a prepared statement
            String sql = "SELECT * FROM products WHERE title = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Bind the title value to the prepared statement
            pstmt.setString(1, title);

            // Execute the prepared statement and get the result set
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String foundIsbn = rs.getString("isbn");
                String foundTitle = rs.getString("title");
                int foundStock = rs.getInt("stock");
                double foundPrice = rs.getDouble("price");
                LocalDate foundPublishDate = rs.getDate("publish_date").toLocalDate();
                Packaging foundPackaging = Packaging.valueOf(rs.getString("box"));

                Product foundProduct = Product.builder()
                        .isbn(foundIsbn)
                        .title(foundTitle)
                        .stock(foundStock)
                        .price(foundPrice)
                        .publishDate(foundPublishDate)
                        .box(foundPackaging)
                        .build();

                System.out.println("Found: " + foundProduct);
            } else {
                System.out.println("No product found with title: " + title);
            }

        } catch (SQLException e) {
            System.out.println("Error searching for product: " + e.getMessage());
        }

        return null;
    }

    @Override
    public void displayAll() {
        System.out.println("Displaying all available products");
        try {
            Connection conn = DbConnection.INSTANCE.getConnection();

            // Create a prepared statement
            String sql = "SELECT * FROM products";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Execute the prepared statement and get the result set
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String foundIsbn = rs.getString("isbn");
                String foundTitle = rs.getString("title");
                int foundStock = rs.getInt("stock");
                double foundPrice = rs.getDouble("price");
                LocalDate foundPublishDate = rs.getDate("publish_date").toLocalDate();
                Packaging foundPackaging = Packaging.valueOf(rs.getString("box"));

                Product foundBook = Product.builder()
                        .isbn(foundIsbn)
                        .title(foundTitle)
                        .stock(foundStock)
                        .price(foundPrice)
                        .publishDate(foundPublishDate)
                        .box(foundPackaging)
                        .build();

                System.out.println(foundBook);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


}

//    @Override
//    public int getQuantity(Product product) {
//        Session session = this.sessionFactory.openSession();
//
//        Query query = session.createNamedQuery("getQuantity", Integer.class);
//        query.setParameter("isbn", product.getIsbn());
//        query.setParameter("title", product.getTitle());
//
//        List<Integer> result = query.getResultList();
//        if (result.isEmpty()) {
//            return 0;
//        } else {
//            return result.get(0);
//        }
//    }









